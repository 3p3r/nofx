#include "globals.h"

namespace nofx
{
	using namespace v8;

	void Initialize(v8::Handle<Object> target,
		v8::Handle<Value> unused,
		v8::Handle<Context> context)
	{
		
		//target->Set(NanNew<v8::String>("..."), NanNew<v8::FunctionTemplate>(...)->GetFunction());

	} //!Initialize
} //!namespace nofx

NODE_MODULE_CONTEXT_AWARE(nofx, nofx::Initialize)