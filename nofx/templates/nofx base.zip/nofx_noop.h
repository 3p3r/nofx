#ifndef _nofx_noop_H_
#define _nofx_noop_H_

#include "globals.h"

namespace nofx
{
	NAN_METHOD(nofx_noop);
} // !namespace nofx

#endif // !_nofx_noop_H_