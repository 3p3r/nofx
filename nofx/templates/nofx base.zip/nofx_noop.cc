#include "nofx_noop.h"

namespace nofx
{
	NAN_METHOD(nofx_noop) {
		NanReturnUndefined();
	} // !nofx_noop
} // !namespace nofx