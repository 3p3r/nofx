#include "$itemname$.h"

namespace $rootnamespace$
{
	NAN_METHOD($itemname$) {
		ASSERT_FALSE(self_.IsEmpty());

		NanScope();
		
		//Insert code here

		NanReturnUndefined();
	} // !$itemname$
} // !namespace $rootnamespace$