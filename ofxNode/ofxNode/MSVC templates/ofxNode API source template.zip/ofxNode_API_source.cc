#include "$itemname$.h"

namespace $rootnamespace$
{
	NAN_METHOD($itemname$) {
		NanScope();

		//Insert code here

		NanReturnValue(args.This());
	} // !$itemname$
} // !namespace $rootnamespace$
