#ifndef _$itemname$_H_
#define _$itemname$_H_

#include "globals.h"

namespace $rootnamespace$
{
	NAN_METHOD($itemname$);
} // !namespace $rootnamespace$

#endif // !_$itemname$_H_